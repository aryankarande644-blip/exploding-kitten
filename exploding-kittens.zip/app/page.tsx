'use client'

import { FormEvent, useState } from 'react'

export default function Page() {
  const [name, setName] = useState('')
  const [roomCode, setRoomCode] = useState('')
  const [message, setMessage] = useState('')

  function createRoom(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setMessage(name.trim() ? `Room created for ${name.trim()}.` : 'Enter your name to create a room.')
  }

  function joinRoom() {
    setMessage(roomCode.trim() ? `Joining room ${roomCode.trim().toUpperCase()}.` : 'Enter a room code to join.')
  }

  return (
    <main className="lobby-shell">
      <div className="scene-art" aria-hidden="true">
        <div className="moon" />
        <div className="window"><span /><span /><span /></div>
        <div className="wall-poster poster-left">KITTENS<br />CARDS<br />CHAOS<br />FRIENDS<br /><b>♡</b></div>
        <div className="wall-poster poster-center">EXPLODING<br />KITTENS<div className="poster-cat">●ᴥ●</div></div>
        <div className="wall-poster poster-right">Good Kittens.<br />Bad Luck.<br /><b>♡</b></div>
        <div className="checklist">☑ Play<br />☑ Betray<br />☑ Explode<br />☑ Repeat<br /><span>ฅ^•ﻌ•^ฅ</span></div>
        <div className="table-scene"><div className="card-stack"><b>EXPLODING<br />KITTENS</b></div><div className="game-card green">DEFUSE<div>●ᴥ●</div></div><div className="game-card blue">SKIP<div>⌁ᴥ⌁</div></div></div>
        <div className="kitten-box"><div className="kitten">◕ᴥ◕</div><span>DANGER<br />CUTE KITTENS<br />INSIDE</span></div>
        <div className="sleeping-cat">⌣ᴥ⌣<i>z z z</i></div>
        <div className="mug">SAME<br />KITTENS<br />DIFFERENT<br />VICTIMS<br />♡</div>
      </div>
      <div className="scene-vignette" aria-hidden="true" />

      <section className="lobby-content" aria-label="Exploding Kittens game lobby">
        <header className="brand-block">
          <div className="brand-title" aria-label="Exploding Kittens">
            <span>EXPLODING</span>
            <strong>KITTENS<sup>™</sup></strong>
          </div>
          <p className="tagline">The card game for people who are into kittens<br /><em>(and occasional explosions).</em></p>
          <div className="paw-row" aria-hidden="true"><span>✦</span><i>●●</i><span>✦</span></div>
        </header>

        <form className="lobby-card" onSubmit={createRoom}>
          <label className="field name-field">
            <span className="field-icon" aria-hidden="true">♙</span>
            <span className="sr-only">Your name</span>
            <input value={name} onChange={(event) => setName(event.target.value)} placeholder="Enter your name..." maxLength={24} />
          </label>

          <button className="create-button" type="submit">
            <span className="people-icon" aria-hidden="true">♟♟♟</span>
            Create Room
          </button>

          <div className="or-divider"><span>OR</span></div>

          <div className="join-row">
            <label className="field code-field">
              <span className="field-icon" aria-hidden="true">⌕</span>
              <span className="sr-only">Room code</span>
              <input value={roomCode} onChange={(event) => setRoomCode(event.target.value.toUpperCase())} placeholder="R O O M  C O D E" maxLength={8} />
            </label>
            <button className="join-button" type="button" onClick={joinRoom}>Join</button>
          </div>
          <p className="status" role="status" aria-live="polite">{message}</p>
        </form>
      </section>

    </main>
  )
}
